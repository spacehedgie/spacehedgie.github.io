Heyo! Thanks for downloading GLITCH BLITZ!
There are 2 different audio formats for GLITCH-BLITZ (.ogg and .mp3) and the artwork for this music. Enjoy!

GLITCH-BLITZ © 2025 by spacehedgie is licensed under Creative Commons Attribution 4.0 International.

